
exports.sign_up =function (req,res) {
    res.render('sign_up')
}