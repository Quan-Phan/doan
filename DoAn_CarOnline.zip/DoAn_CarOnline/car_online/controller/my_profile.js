
exports.my_profile=function (req,res) {
    res.render('my_profile');
};