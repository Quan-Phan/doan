
exports.take_pass =function (req,res) {
    res.render('take_pass_again')
}